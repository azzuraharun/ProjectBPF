<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Tamu extends REST_Controller 
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Tamu_model', 'tm');
    }

    public function index_get()
    {
        $id = $this->get('id');
        if($id == null){
            $tamu = $this->tm->get();
        }
        else{
            $tamu = $this->tm->get($id);
        }

        if($tamu){
            $this->response([
                'status' => true,
                'data' => $tamu
            ], REST_Controller::HTTP_OK);
        }
        else{
            $this->response([
                'status' => true,
                'message' => 'Id tidak ditemukan'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function index_delete()
    {
        $id = $this->delete('id');
        if($id == null){
            $this->response([
                'status' => false,
                'message' => 'Masukkan ID'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
        else{
            if($this->tm->delete($id) > 0){
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'Data berhasil dihapus'
                ], REST_Controller::HTTP_OK);
            }
            else{
                $this->response([
                    'status' => false,
                    'message' => 'ID tidak ditemukan'
                ], REST_Controller::HTTP_NOT_FOUND);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'nama' => $this->post('nama'),
            'alamat' => $this->post('alamat'),
            'no_hp' => $this->post('no_hp'),            
            'check_in' => $this->post('check_in'),
            'check_out' => $this->post('check_out'),
            'jenis_kamar' => $this->post('jenis_kamar')
        ];
        if($this->tm->insert($data) > 0){
            $this->response([
                'status' => true,
                'message' => 'Data berhasil ditambahkan'
            ], REST_Controller::HTTP_CREATED);
        }
        else{
            $this->response([
                'status' => false,
                'message' => 'Gagal menambahkan data'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function index_put()
    {
        $id = $this->put('id');
        $data = [
            'nama' => $this->put('nama'),
            'alamat' => $this->put('alamat'),
            'no_hp' => $this->put('no_hp'),            
            'check_in' => $this->put('check_in'),
            'check_out' => $this->put('check_out'),
            'jenis_kamar' => $this->put('jenis_kamar')
        ];
        if($this->tm->update($data, $id) > 0){
            $this->response([
                'status' => true,
                'message' => 'Data berhasil diubah'
            ], REST_Controller::HTTP_OK);
        }
        else{
            $this->response([
                'status' => false,
                'message' => 'Gagal mengubah data'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
}